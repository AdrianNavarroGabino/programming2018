﻿class Score
{
    public int Points { get; set; }
    public string Name { get; set; }

    public Score(int points, string name)
    {
        Points = points;
        Name = name;
    }
}
