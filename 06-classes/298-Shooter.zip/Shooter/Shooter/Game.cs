﻿class Game
{
    public void Init()
    {
        // TO DO
    }

    public void Launch()
    {
        // TO DO
    }

    public void DrawScreen()
    {
        // TO DO
    }

    public void CheckColisions()
    {
        // TO DO
    }
}
