﻿class Image
{
    // TO DO
}
