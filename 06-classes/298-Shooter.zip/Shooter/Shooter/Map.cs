﻿class Map
{
    protected int score;
    protected int level;

    public void SetScore(int newScore) { score = newScore; }
    public void SetLevel(int newLevel) { level = newLevel; }

    public int GetScore() { return score; }
    public int GetLevel() { return level; }

    public Map(int newScore, int newLevel)
    {
        SetScore(newScore);
        SetLevel(newLevel);
    }
}
