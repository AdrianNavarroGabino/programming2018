﻿class Player : Character
{
    protected int ammo;
    protected int lives;

    public void SetAmmo(int newAmmo) { ammo = newAmmo; }
    public void SetLives(int newLives) { lives = newLives; }

    public int GetAmmo() { return ammo; }
    public int GetLives() { return lives; }

    public Player(int newAmmo, int newLives, bool newAlive, float newSpeed,
        int newX, int newY, int newSize, Image newImage)
    {
        SetAmmo(newAmmo);
        SetLives(newLives);
        SetIsAlive(newAlive);
        SetSpeed(newSpeed);
        SetX(newX);
        SetY(newY);
        SetSize(newSize);
        SetImage(newImage);
    }
}
