﻿class Character : Sprite
{
    protected bool isAlive;
    protected float speed;

    public void SetIsAlive(bool newAlive) { isAlive = newAlive; }
    public void SetSpeed(float newSpeed) { speed = newSpeed; }

    public bool GetIsAlive() { return isAlive; }
    public float GetSpeed() { return speed; }

    public Character(bool newAlive, float newSpeed, int newX, int newY,
        int newSize, Image newImage)
    {
        SetIsAlive(newAlive);
        SetSpeed(newSpeed);
        SetX(newX);
        SetY(newY);
        SetSize(newSize);
        SetImage(newImage);
    }

    public Character()
    {
    }

    public void Move()
    {
        // TO DO
    }

    public void DeathAnimation()
    {
        // TO DO
    }

    public void Shoot()
    {
        // TO DO
    }
}
