﻿class Sprite
{
    protected int x;
    protected int y;
    protected int size;
    protected Image image;

    public void SetX(int newX) { x = newX; }
    public void SetY(int newY) { y = newY; }
    public void SetSize(int newSize) { size = newSize; }
    public void SetImage(Image newImage) { image = newImage; }

    public int GetX() { return x; }
    public int GetY() { return y; }
    public int GetSize() { return size; }
    public Image GetImage() { return image; }

    public Sprite(int newX, int newY, int newSize, Image newImage)
    {
        SetX(newX);
        SetY(newY);
        SetSize(newSize);
        SetImage(newImage);
    }

    public Sprite()
    {
    }
}
