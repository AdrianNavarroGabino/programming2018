﻿using System;

class Shooter
{
    static void Main(string[] args)
    {
        Character c = new Character();
    }
}
