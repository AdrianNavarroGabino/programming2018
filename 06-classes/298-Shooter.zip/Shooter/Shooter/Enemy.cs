﻿class Enemy : Character
{
    public Enemy(bool newAlive, float newSpeed, int newX, int newY,
        int newSize, Image newImage)
    {
        SetIsAlive(newAlive);
        SetSpeed(newSpeed);
        SetX(newX);
        SetY(newY);
        SetSize(newSize);
        SetImage(newImage);
    }

    public void Spawn()
    {
        // TO DO
    }
}
